import traceback
import sys

if (len(sys.argv)>1):
  text =""
  for Lp in sys.argv[2:]:
    text +=Lp
  text =text.replace("[Lnote_LF]","\n").replace("[Lnote_DQ]",'"').replace("[Lnote_SQ]","'").replace("[Lnote_PC]","%")

  if (sys.argv[1]=="error"):
    print("ProcessError!\n\n\n"+text)
    print("\nYou should quit the Application manually.")
    print("Perhaps, a backup has been made if you're editing.")

  elif (sys.argv[1]=="script"):
    try:
      exec(text)
    except:
      print(traceback.format_exc())
  
  input("\n\n\n\nPlease Enter:")