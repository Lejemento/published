# coding: utf-8
# coding by Lejemento
# L-ytdl v1.0



# ライブラリ
import os
import time
import shutil
import threading
import subprocess



# ダウンロード完了ファイルを自動移動
def filemove(List0):
  List1 =os.listdir(path=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")
  Diff =set(List1)-set(List0)
  while len(Diff):
    Diff_LP =Diff.pop()
    if (Diff_LP[-5:] == ".part"): continue
    shutil.move(os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps/"+Diff_LP,os.path.abspath(os.path.dirname(__file__))+"/")



def main():
  # ファイルからIDを読込
  try:
    File =open(os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps/nicoIDs.txt")
    nicoID =[]
    for File_LP in File:
      nicoID.append(File_LP.strip()[5:])
    File.close()
  except:
    nicoID =["",""]

  # 自動更新
  print("  [L-ytdl] youtube-dl Auto Update")
  P0 =subprocess.Popen("python youtube-dl -U",cwd=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")
  P0.wait()


  # メインループ
  while 1:
    # CLI的入力
    UserStr =input("\a  [L-ytdl] Command :")

    #____正規終了
    if (UserStr.strip() == "exit"):
      print("  [L-ytdl] waitting RetryTimer")
      break
    #____ニコ動以外のとき
    if not("nicovideo.jp/watch" in UserStr):
      List =os.listdir(path=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")
      P0 =subprocess.Popen("python youtube-dl "+UserStr,cwd=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")
      P0.wait()
      filemove(List)
    #____ニコ動のとき
    else:
      # 自動ログイン
      UserID =""
      if not(nicoID[0]=="" or nicoID[1]==""):
        UserID ="-u "+nicoID[0]+" -p "+nicoID[1]+" "
        print("  [L-ytdl] niconico Auto Login")

      # ループ
      flag =1
      while flag:
        List =os.listdir(path=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")
        P0 =subprocess.Popen("python youtube-dl "+UserID+UserStr,cwd=os.path.abspath(os.path.dirname(__file__))+"/!_L-ytdl_apps")

        # タイムアウト
        def T1_timer():
          time.sleep(25)
        T1 =threading.Thread(target=T1_timer)
        T1.start()

        # 自動リトライ
        while 1:
          if((P0.poll()!=None)==1):
            flag =0
            break
          elif(T1.is_alive() == False):
            P0.terminate()
            time.sleep(0.1)
            print("\n  [L-ytdl] niconico Auto Retrying")
            break
      filemove(List)



if (__name__=='__main__'):
  main()