# coding: utf-8
# coding by Lejemento
# L-ytdl v1.2



# ライブラリ
import os
import time
import shutil
import threading
import subprocess

# グローバル宣言
SYS_dir =None
SYS_files =None
SYS_IDs =None



# 初期化
def pre():
  global SYS_dir,SYS_files,SYS_IDs
  path =os.path.dirname(os.path.abspath(__file__))
  path =path.replace('\\\\','/').replace('\\','/')
  if (path[-1]=="/"):
    path =path[:-1]
  SYS_dir =path


# main
def main():
  global SYS_dir,SYS_files,SYS_IDs

  # 必要ファイルのチェック
  check =False
  while (True):
    if (os.path.isdir(SYS_dir+"/!_L-ytdl_apps")): pass
    else: break
    if (os.path.isfile(SYS_dir+"/!_L-ytdl_apps/ffmpeg.exe")): pass
    else: break
    if (os.path.isfile(SYS_dir+"/!_L-ytdl_apps/nicoIDs.txt")): pass
    else: break
    if (os.path.isfile(SYS_dir+"/!_L-ytdl_apps/youtube-dl")): pass
    else: break
    check =True
    break
  if not(check):
    print(u" 【L-ytdl】\aFailed to start. Dont't enough necessary files.")
    time.sleep(4)
    return
  
  # youtube-dlの更新
  print(u" 【L-ytdl】Auto updating.")
  P0 =subprocess.Popen("python youtube-dl -U",cwd=SYS_dir+"/!_L-ytdl_apps")
  P0.wait()

  # .partファイルの報告
  ListA =os.listdir(path=SYS_dir+"/!_L-ytdl_apps")
  for tp_List in ListA:
    if (tp_List[-5:]==".part" or tp_List[-5:]==".ytdl"):
      print(u" 【L-ytdl】The temp file exists. /!_L-ytdl_apps/"+tp_List)

  # IDファイルの確認
  File =open(SYS_dir+"/!_L-ytdl_apps/nicoIDs.txt")
  SYS_IDs =[]
  try:
    for tp_File in File:
      SYS_IDs.append(tp_File.strip()[5:])
  except:
    SYS_IDs =["",""]
  File.close()



  # メインループ
  print(u" 【L-ytdl】Normal starting.")
  while (True):
    #____CLI的入力
    UserStr =input(u" 【L-ytdl】\aCommand >")
    #____空白
    if (UserStr.strip()==""):
      print(u" 【L-ytdl】Finish:'exit'  Help:'help'")
      continue
    #____ヘルプ
    if (UserStr.strip()=="help"):
      caseHelp()
      continue
    #____終了
    if (UserStr.strip()=="exit" or UserStr.strip()=="quit"):
      break
    
    # ディレクトリ内の記録
    SYS_files =os.listdir(path=SYS_dir+"/!_L-ytdl_apps")
    #____ニコニコ動画
    if ("nicovideo.jp/" in UserStr):
      caseNico(UserStr)
    #____他
    else:
      caseOther(UserStr)

    # ダウンロードファイルの移動
    fileMove()


  print(u" 【L-ytdl】Normal closing.")



# ニコニコの時
def caseNico(UserStr):
  global SYS_dir,SYS_files,SYS_IDs
  if (SYS_IDs[0]=="" or SYS_IDs[1]==""):
    UserID =""
  else:
    UserID ="-u "+SYS_IDs[0]+" -p "+SYS_IDs[1]+" "
    print(u" 【L-ytdl】Auto niconico logging in.")

  # リトライ
  flag =True
  while (flag):
    P0 =subprocess.Popen("python youtube-dl "+UserID+UserStr,cwd=SYS_dir+"/!_L-ytdl_apps")
    
    # リトライタイマー
    def T1_timer():
      time.sleep(22)
    T1 =threading.Thread(target=T1_timer)
    T1.start()

    try:
      # ダウンロード強制中止
      while (True):
        if not(P0.poll() is None):
          # もしプロセスが死んでたら
          flag =False
          break
        elif (T1.is_alive() is False):
          # もしタイマーが切れてたら
          P0.terminate()
          time.sleep(0.1)
          print(u"\n 【L-ytdl】Auto niconico retrying.")
          break
        time.sleep(0.0001)
        
    except KeyboardInterrupt:
      time.sleep(1)
      print(u" 【L-ytdl】Interrupt stopping by ctrl+C.")
      fileDel()
      break

# ニコニコ以外の時
def caseOther(UserStr):
  global SYS_dir,SYS_files,SYS_IDs
  P0 =subprocess.Popen("python youtube-dl "+UserStr,cwd=SYS_dir+"/!_L-ytdl_apps")
  try:
    P0.wait()
  except KeyboardInterrupt:
    time.sleep(1)
    print(u" 【L-ytdl】Interrupt stopping by ctrl+C.")
    fileDel()

# ヘルプ
def caseHelp():
  Text =u""" ========================================
 L-ytdl ver1.2
 Action : youtube-dl commands
 Stop DL: ctrl+C
 Test DL: "-f 136+140 https://youtu.be/MGt25mv4-2Q"
 Help   : "help" (youtube-dl:"-help")
 Finish : "exit" or "quit"
 ========================================"""
  print(Text)

# ファイルの移動
def fileMove():
  global SYS_dir,SYS_files,SYS_IDs
  List0 =SYS_files
  List1 =os.listdir(path=SYS_dir+"/!_L-ytdl_apps")
  ListD =set(List1)-set(List0)
  for tp_List in ListD:
    if not(tp_List[-5:]==".part" or tp_List[-5:]==".ytdl"):
      shutil.move(SYS_dir+"/!_L-ytdl_apps/"+tp_List,SYS_dir+"/")

# ファイルの削除
def fileDel():
  global SYS_dir,SYS_files,SYS_IDs
  List0 =SYS_files
  List1 =os.listdir(path=SYS_dir+"/!_L-ytdl_apps")
  ListD =set(List1)-set(List0)
  for tp_List in ListD:
    if (tp_List[-5:]==".part" or tp_List[-5:]==".ytdl"):
      os.remove(SYS_dir+"/!_L-ytdl_apps/"+tp_List)


if (__name__=='__main__'):
  pre()
  main()